
 $(document).ready(function() {
    const DATA_COUNT = 7;
    const NUMBER_CFG = {count: DATA_COUNT, rmin: 5, rmax: 15, min: 0, max: 100};
    
    var popData = {
        datasets: [{
          label: ['Happy Population'],
          data: [{
            x: 100,
            y: 0,
            r: 10
          }, {
            x: 60,
            y: 30,
            r: 20
          }, {
            x: 40,
            y: 60,
            r: 25
          }, {
            x: 80,
            y: 80,
            r: 50
          }, {
            x: 20,
            y: 30,
            r: 25
          }, {
            x: 0,
            y: 100,
            r: 5
          }],
          backgroundColor: "#FF9966"
        },        {
          label: ['Internet Users'],
          data: [ {
            x: 10,
            y: 30,
            r: 20
          }, {
            x: 100,
            y: 40,
            r: 20
          }, {
            x: 50,
            y: 70,
            r: 50
          }, {
            x: 20,
            y: 30,
            r: 25
          }, {
            x: 40,
            y: 60,
            r: 25
          },{
            x: 0,
            y: 100,
            r: 5
          }],
          backgroundColor: "#ffb1c1"
        }]
      };
    
     let myChart = document.getElementById('myChart').getContext('2d')
    
const config = {
    type: 'bubble',
    data: popData,
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: 'Chart.js Bubble Chart'
        }
      }
    },
  };

  massPopChart = new Chart(myChart, config );
} );