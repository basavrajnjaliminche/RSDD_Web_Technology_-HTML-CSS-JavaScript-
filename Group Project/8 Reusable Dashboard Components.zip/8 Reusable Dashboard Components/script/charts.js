var jsonDataLoaded;
let massPopChart;
var config;

  $(document).ready(function() {
  var jsonFileLoaded = $.getJSON( "/json/dataset.json", function() {
    jsonDataLoaded = jsonFileLoaded.responseJSON.ChartDataSet;
    console.log( "success");
  }).fail(function(){
    console.log("An error has occurred.");
});
    
});
 
function charts(chartId,chartType) {
    setTimeout(function() {
        myCharts(chartId,chartType);
    }, 200);
}

function myCharts(chartId,chartType){

  let myChart = document.getElementById(chartId).getContext('2d')
  // Global options
  Chart.defaults.font.family = 'Lato';
  Chart.defaults.font.size = 16;
  Chart.defaults.color = '#777';
  
   config = {
    type: chartType,
    data: {
        labels: ['Category 1', 'Category 2' , 'Category 3', 'Category 4' , 'Category 5', 'Category 6'],
        datasets: [{
            label: 'Dataset 1',
            data: [
                jsonDataLoaded[0],
                jsonDataLoaded[1],
                jsonDataLoaded[2],
                jsonDataLoaded[3],
                jsonDataLoaded[4],
                jsonDataLoaded[5]
                
            ],
            backgroundColor: [
            'rgb(255, 99, 132)',
            'rgb(75, 192, 192)',
            'rgb(255, 205, 86)',
            'rgb(201, 203, 207)',
            'rgb(54, 162, 235)'
            ],
            borderWidth: 1,
            borderColor: '#777',
            hoverBorderWidth: 3,
            hoverBorderColor: '#000',
        }],
    },
    options: {
        indexAxis: 'x',
        plugins: {
            title: {
                display: true,
                text: chartType.toUpperCase()+' CHART',
                font: {
                    size: 25
                }
            },
            legend: {
                display: true,
                position: 'left',
                labels: {
                    color: 'black'
                }
            },
            scales: {
                xAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: ''
                        }
                    }],
                yAxes: [{
                        display: true,
                        ticks: {
                            beginAtZero: true,
                            steps: 10,
                            stepValue: 5,
                            max: 100
                        }
                    }]
            },
            tooltip: {
                enabled: true // Default
            }
        },
        layout: {
            padding: {
                left: 50,
                right: 0,
                bottom: 10,
                top: 0
            }
        },

    }

  };
  

   massPopChart = new Chart(myChart, config );

  
}

function a(){
    
    

    var newDataset = {
     
        label: 'Dataset 2',
        backgroundColor: [
            'rgb(255, 99, 132)',
            'rgb(75, 192, 192)',
            'rgb(255, 205, 86)',
            'rgb(201, 203, 207)',
            'rgb(54, 162, 235)'
            ],
            borderWidth: 1,
            borderColor: '#777',
            hoverBorderWidth: 3,
            hoverBorderColor: '#000',
        data: [],
        fill: false
    };

    newDataset.data.push(11);
    newDataset.data.push(21);
    newDataset.data.push(31);
    newDataset.data.push(24);
    newDataset.data.push(41);
    newDataset.data.push(12);
    config.data.datasets.push(newDataset);
    
    massPopChart.update();

}





