
        $(document).ready(function() {
            var t =    $('#example').DataTable();
       
           
        $.getJSON("/json/dataset.json", function(data){
            $.each(data.Employees, function(index, element) {
                t.row.add( [
                element.name,
                element.email,
                element.location,
                element.creationDate
           
            
        ] ).draw( false );
                });
       
        }).fail(function(){
            console.log("An error has occurred.");
        });

    } );
